---
title: Contact
featured_image: ''
omit_header_text: true
description: Laissez-nous un message!
type: page
menu: main

---

Ceci est la page de contact en Français.

This is an example of a custom shortcode that you can put right into your content. You will need to add a form action to the shortcode to make it work. Check out [Formspree](https://formspree.io/) for a simple, free form service.

{{< form-contact action="https://example.com"  >}}
